# kuraztech

Internship program first challenge
